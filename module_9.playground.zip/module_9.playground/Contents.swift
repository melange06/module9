let driveMode = ["Manual", "Auto"]

let massKg = 2108
let lengthMm = 4976
let widthWithSideMirrorsMm = 1963
let heightMm = 1435
let wheelBaseMm = 2959
let clearanceMm = 154.9
let trunkVolumeL = 900

let musicVolume = [0...10]
let sunRoofPercentage = [0...100]
let fanSpeed = [0...10]
let driverClimateControl = ["On", "Off"]

enum AutoError: Error {
    case isLost
    case lowBattery
    case autoDriveIsBroken
    case sunRoofIsOpen
}

var isLost: Bool = false
var lowBattery: Bool = false
var autoDriveIsBroken: Bool = false
var sunRoofIsOpen: Bool = false

do {
    if isLost {
        throw AutoError.isLost
    }
    
    if lowBattery {
        throw AutoError.lowBattery
    }
    
    if autoDriveIsBroken {
        throw AutoError.autoDriveIsBroken
    }
    
    if sunRoofIsOpen {
        throw AutoError.sunRoofIsOpen
    }
    
} catch AutoError.isLost {
    print("GPS is ON")
} catch AutoError.lowBattery {
    print("The nearest station is in 1 km")
} catch AutoError.autoDriveIsBroken {
    print("Manual mode is ON")
} catch AutoError.sunRoofIsOpen {
    print("Close Sunroof")
}

























